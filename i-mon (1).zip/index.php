<?php 
    require 'dashboard/proses/koneksi.php';
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />

    <!-- Rubik Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Scroll Animate -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v6.0.0-beta3/css/all.css">

    <title>I-MON | Air Minum Masak</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light position-sticky sticky-top">
        <div class="container py-2">
            <a class="navbar-brand" href="#">
                <img src="images/i-mon_logo.png" alt="" height="30">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="ms-auto">
                <a class="btn btn-cta" href="dashboard/" role="button">
                    <?php 
                        if (!isset($_SESSION['email'])) {
                            echo 'Masuk';
                        } elseif (isset($_SESSION['email'])) {
                            echo 'Dashboard';
                        }
                    ?>
                </a>
            </div>
        </div>
    </nav>

    <section id="home" class="hero-section">
        <div class="container py-3">
            <div class="row align-items-center">
                <div class="col-md-6 order-md-1 text-md-end mb-5 mb-md-0" data-aos="fade-left" data-aos-duration="1000">
                    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="hero-img carousel-item active">
                                <img class="text-end" src="images/i-mon.png" class="d-block" alt="..." width="100%">
                            </div>
                            <div class="hero-img carousel-item">
                                <img class="text-end" src="images/hero.png" class="d-block" alt="..." width="100%">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 order-md-0" data-aos="fade-right" data-aos-duration="1000">
                    <h5 class="fw-light text-secondary">WELCOME TO</h5>
                    <h1 class="display-3 fw-bold lh-sm">I-MON Masak</h1>
                    <p class="hero-desc">
                        Air minum masak yang diproduksi dengan cara tradisional
                    </p>
                    <div class="social-media d-flex my-4">
                        <p class="text-secondary">Follow Us</p>
                        <a class="media-icon link-secondary ms-3" href="#">
                            <i class="fa-brands fa-instagram fa-2x"></i>
                        </a>
                        <a class="media-icon link-secondary ms-3" href="#">
                            <i class="fa-brands fa-youtube fa-2x"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>