<?php

require 'proses/koneksi.php';
require "proses/session.php";

$sql = mysqli_query($conn, "SELECT level FROM tb_users WHERE email = 'rizkysafdila@gmail.com'");
$level = mysqli_fetch_assoc($sql);

$query = mysqli_query($conn, 'SELECT * FROM tb_users u
                              LEFT JOIN tb_profiles cust ON u.id = cust.id_user
                    ');
$count = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" /> -->
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Rubik Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Datatables Style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">

    <!-- Dashboard Style -->
    <link rel="stylesheet" href="css/dashboard.css">

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v6.0.0-beta3/css/all.css">

    <title>Dashboard - I-MON</title>
</head>

<body>
    <div class="navbar navbar-light sticky-top bg-light d-md-none flex-md-nowrap pb-5 shadow">
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fa-solid fa-bars display-6"></span>
        </button>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <!-- Sidebar -->
                <?php require 'components/sidebar.php' ?>
                <!-- End Sidebar -->
            </div>

            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <header>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 my-3">
                        <h1 class="h2">User Accounts</h1>
                        <!-- User Menu -->
                        <?php require 'components/user_menu.php' ?>
                        <!-- End User Menu -->
                    </div>
                </header>

                <main>
                    <div class="row">
                        <div class="col-sm-6 col-lg-3 mt-3">
                            <div class="card users-info bg-white p-1 shadow-sm border-2">
                                <div class="card-body">
                                    <i class="fa-duotone fa-user-group fa-2x p-2 rounded-3 bg-dark"></i>
                                    <h4 class="card-title mt-3"><?= $count ?></h4>
                                    <p class="card-text lh-1">
                                        <?php
                                        if ($count > 1) {
                                            echo 'Users';
                                        } else {
                                            echo 'User';
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card my-4 shadow">
                        <div class="card-body">
                            <button type="button" class="btn btn-primary rounded-3 my-3" data-bs-toggle="modal" data-bs-target="#addModal">
                                <i class="fa-regular fa-plus me-1"></i>
                                Tambah User
                            </button>

                            <table id="example" class="table responsive nowrap table-bordered table-striped align-middle" style="width:100%">
                                <thead>
                                    <tr class="bg-white">
                                        <th scope="col">No</th>
                                        <th scope="col">Foto Profil</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Telepon</th>
                                        <th scope="col">Alamat</th>
                                        <th scope="col">Level</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $num = 1;
                                    while ($data = mysqli_fetch_assoc($query)) :
                                    ?>
                                        <tr>
                                            <td><?= $num ?></td>
                                            <td class="text-center">
                                                <?php
                                                if (empty($data['foto'])) {
                                                    $foto = 'avatar.png';
                                                } else {
                                                    $foto = $data['foto'];
                                                }
                                                ?>
                                                <img class="profile-pict rounded-3" src="img/<?= $foto ?>" alt="" width="75px" height="75px">
                                            </td>
                                            <td><?= $data['email'] ?></td>
                                            <td><?= $data['nama'] ?></td>
                                            <td>
                                                <?php
                                                $telepon = $data['telepon'];
                                                $telepon = str_split($telepon, 4);
                                                $telepon = implode('-', $telepon);
                                                echo $telepon;
                                                ?>
                                            </td>
                                            <td class="text-center">
                                                <button type="button" class="btn btn-info rounded-3" data-bs-toggle="modal" data-bs-target="#addressModal<?= $num ?>">
                                                    <i class="fa-regular fa-location-dot me-1"></i>
                                                    Lihat
                                                </button>
                                            </td>
                                            <td>
                                                <b><?= ucfirst($data['level']) ?></b>
                                            </td>
                                            <td class="text-center">
                                                <div class="dropdown">
                                                    <button class="btn btn-outline-secondary fa-regular fa-ellipsis-vertical" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                    </button>
                                                    <ul class="dropdown-menu p-2" aria-labelledby="dropdownMenuButton1">
                                                        <li>
                                                            <a href="#resetPw<?= $num ?>" class="dropdown-item" data-bs-toggle="modal">
                                                                <i class="fa-regular fa-lock me-1"></i>
                                                                Reset Password
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#editModal<?= $num ?>" class="dropdown-item" data-bs-toggle="modal">
                                                                <i class="fa-regular fa-pen-to-square me-1"></i>
                                                                Edit
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#deleteModal<?= $num ?>" class="dropdown-item" data-bs-toggle="modal">
                                                                <i class="fa-regular fa-trash-can me-1"></i>
                                                                Hapus
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                        <!-- reset password user modal -->
                                        <div class="modal fade" id="resetPw<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-md">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Tambah User Baru</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="proses/proses_users/reset_password.php" method="post">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id" value="<?= $data["id"]; ?>">
                                                            <div class="mb-3">
                                                                <label for="newpassword" class="form-label">Password Baru</label>
                                                                <input type="password" class="form-control" name="newpassword" id="newpassword" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="newpassword2" class="form-label">Konfirmasi Password Baru</label>
                                                                <input type="password" class="form-control" name="newpassword2" id="newpassword2" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end reset password user modal -->

                                        <!-- edit user modal -->
                                        <div class="modal fade" id="editModal<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="proses/proses_users/edit_user.php" method="post">
                                                        <input type="hidden" name="id_user" value="<?= $data['id'] ?>">
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="email" class="form-label">Email</label>
                                                                <input type="email" class="form-control" id="email" name="email" value="<?= $data['email'] ?>" disabled>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="nama" class="form-label">Nama</label>
                                                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $data['nama'] ?>">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="telepon" class="form-label">Nomor Telepon</label>
                                                                <input type="text" class="form-control" id="telepon" name="telepon" value="<?= $data['telepon'] ?>">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="alamat" class="form-label">Alamat</label>
                                                                <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $data['alamat'] ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-primary">Perbarui</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end edit user modal -->

                                        <!-- delete user modal -->
                                        <div class="modal fade" id="deleteModal<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-md">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="proses/proses_users/hapus_user.php" method="post">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_user" value="<?= $data['id'] ?>">
                                                            <p>Apakah anda yakin ingin menghapus akun <?= $data['email'] ?>?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end delete user modal -->

                                        <!-- alamat user modal -->
                                        <div class="modal fade" id="addressModal<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Lihat Alamat</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>
                                                            <?= $data['alamat'] ?>
                                                        </p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end alamat user modal -->
                                    <?php
                                        $num++;
                                    endwhile;
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- add user modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah User Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="proses/proses_users/tambah_user.php" method="post">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="password2" class="form-label">Konfirmasi Password</label>
                            <input type="password" class="form-control" id="password2" name="password2">
                        </div>
                        <div class="mb3">
                            <label for="level" class="form-label">Level</label>
                            <select class="form-select" id="level" name="level">
                                <option value="admin">Admin</option>
                                <option value="user" selected>User</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end add user modal -->



    <!-- Datatables Js -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>

    <script src="js/datatables.js"></script>

    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>