<?php
require '../koneksi.php';
require '../session.php';

$idUser = $_POST['id_user'];
$nama = $_POST['nama'];
$telepon = $_POST['telepon'];
$alamat = $_POST['alamat'];

$update = mysqli_query($conn, "UPDATE tb_profiles SET
                                        nama = '$nama',
                                        telepon = '$telepon',
                                        alamat = '$alamat'
                                    WHERE id_user = $idUser
                            ");

if ($update) {
    echo "<script>
                alert('User berhasil diubah');
                window.location = '../../users';
            </script>";
} else {
    echo "<script>
                alert('User gagal diubah');
                window.location = '../../users';
            </script>";
}
