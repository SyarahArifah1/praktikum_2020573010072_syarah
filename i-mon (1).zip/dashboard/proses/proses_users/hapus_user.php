<?php 
    require '../koneksi.php';

    $idUser = $_POST['id_user'];

    // hapus akun users
    $deleteUser = mysqli_query($conn, "DELETE FROM tb_users WHERE id = $idUser");
    if ( $deleteUser ) {
        echo "<script>
                alert('User berhasil dihapus');
                window.location = '../../users';
              </script>";
    }
    else {
        echo "<script>
                alert('User gagal dihapus');
                window.location = '../../users';
              </script>";
    }
    
