<?php 

require '../koneksi.php';

$email = strtolower($_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$password2 = mysqli_real_escape_string($conn, $_POST['password2']);
$level = $_POST['level'];

// cek email sudah terdaftar atau belum
$cekEmail = mysqli_query($conn, "SELECT email FROM tb_users WHERE email = '$email'");
if ( mysqli_fetch_assoc($cekEmail) ) {
    echo "<script>
            alert('email sudah terdaftar!');
            window.location = '../../users';
          </script>";
} else {
    // cek konfirmasi password
    if ( $password !== $password2 ) {
        echo "<script>
                alert('konfirmasi password tidak sesuai');
                window.location = '../../users';
              </script>";
    } else {
        // enkripsi password
        $password = md5($password);

        // tambahkan user baru ke database
        $result = mysqli_query($conn, "INSERT INTO tb_users (email, password, level) VALUES ('$email', '$password', '$level')");
        if ( $result ) {
            echo "<script>
                    alert('User berhasil ditambahkan');
                    window.location = '../../users';
                  </script>";
        }
        else {
            echo "<script>
                    alert('User gagal ditambahkan');
                    window.location = '../../users';
                  </script>";
        }
    }
}