<?php
require '../koneksi.php';

// ambil id dari halaman settings.php
$id = $_POST["id"];

$NewPassword = $_POST['newpassword'];
$NewPassword2 = $_POST['newpassword2'];

// cek konfirmasi password
if ($NewPassword !== $NewPassword2) {
    echo "<script>
                alert('konfirmasi password tidak sesuai');
                window.location = '../../users';
              </script>";
} else {
    // enkripsi passsword
    $NewPassword = md5($NewPassword);

    // update password pada database
    mysqli_query($conn, "UPDATE tb_users SET password = '$NewPassword' WHERE id = $id");

    // cek apakah password berhasil di update pada database
    $berhasil = mysqli_affected_rows($conn);
    if ($berhasil > 0) {
        echo "<script>
                alert('Password berhasil diubah!');
                window.location = '../../users';
              </script>";
    } else {
        echo "<script>
                alert('Password gagal diubah!');
                window.location = '../../users';
              </script>";
    }
}
