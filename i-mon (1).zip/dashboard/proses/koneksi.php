<?php 

$conn = mysqli_connect('localhost', 'root', '', 'i_mon') or die("Koneksi Gagal");