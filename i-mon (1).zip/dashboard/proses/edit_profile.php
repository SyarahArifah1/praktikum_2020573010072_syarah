<?php
require 'koneksi.php';
require 'session.php';

$idProfile = $_POST['id_profile'];
$nama = htmlspecialchars($_POST['nama']);
$telepon = htmlspecialchars($_POST['telepon']);
$alamat = htmlspecialchars($_POST['alamat']);
$fotoLama = $_POST['fotoLama'];

// cek apakah user pilih gambar baru atau tidak
if ($_FILES["foto"]["error"] == 4) {
    $foto = $fotoLama;
} else {
    unlink("../img/" . $fotoLama);
    $foto = upload();
}

$input = mysqli_query($conn, "UPDATE tb_profiles SET
                                        nama = '$nama',
                                        telepon = '$telepon',
                                        foto = '$foto',
                                        alamat = '$alamat'
                                    WHERE id_profile = $idProfile
                            ");
if ($input) {
    echo "<script>
            alert('Profile berhasil diperbarui');
            window.location.href = '../profile';
        </script>";
} else {
    echo "<script>
            alert('Profile gagal diperbarui');
            window.location = '../profile';
        </script>";
}


function upload()
{
    $namaFile = $_FILES['foto']['name'];
    $ukuranFile = $_FILES['foto']['size'];
    $error = $_FILES['foto']['error'];
    $tmpName = $_FILES['foto']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        echo "
            <script>
                alert('Pilih gambar terlebih dahulu!');
                window.location = '../profile';
            </script>";
    } else {
        // cek apakah yang diupload adalah gambar
        $validImageExt = ['jpg', 'jpeg', 'png'];
        $imageExt = explode('.', $namaFile);
        $imageExt = strtolower(end($imageExt));

        if (!in_array($imageExt, $validImageExt)) {
            echo "
            <script>
                alert('Yang anda upload bukan gambar!');
                window.location = '../profile';
            </script>";
        }
        // cek jika ukurannya terlalu besar
        elseif ($ukuranFile > 2000000) {
            echo "
            <script>
                alert('Ukuran gambar terlalu besar!');
                window.location = '../profile';
            </script>";
        } else {
            // lolos pengecekan, gambar siap diupload
            // generate nama gambar baru
            $namaFileBaru = uniqid();
            $namaFileBaru .= '.';
            $namaFileBaru .= $imageExt;

            move_uploaded_file($tmpName, '../img/' . $namaFileBaru);

            return $namaFileBaru;
        }
    }
}
