<?php
require '../koneksi.php';
require '../session.php';

$idOrder = $_POST['id_order'];
$user = $_POST['user'];
$totalBayar = $_POST['total_bayar'];

$input = mysqli_query($conn, "INSERT INTO tb_transaksi (id_order, user, total_bayar, status_transaksi)
                                        VALUES ($idOrder, $user, $totalBayar, 1)
                            ");
$status = mysqli_query($conn, "UPDATE tb_orders SET status_order = 4 WHERE id_order = $idOrder");
if ($input) {
    echo "<script>
                window.location = '../../transaksi';
            </script>";
} else {
    echo "<script>
                window.location = '../../transaksi';
            </script>";
}
