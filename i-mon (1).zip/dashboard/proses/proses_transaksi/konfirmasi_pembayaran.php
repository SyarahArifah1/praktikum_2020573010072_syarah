<?php
require '../koneksi.php';
require '../session.php';

$idTransaksi = $_POST['id_transaksi'];
$idOrder = $_POST['id_order'];

$status = mysqli_query($conn, "UPDATE tb_orders SET status_order = 2 WHERE id_order = $idOrder");
$status1 = mysqli_query($conn, "UPDATE tb_transaksi SET status_transaksi = 2 WHERE id_transaksi = $idTransaksi");
if ($status1) {
    echo "<script>
                window.location = '../../transaksi';
            </script>";
} else {
    echo "<script>
                window.location = '../../transaksi';
            </script>";
}
