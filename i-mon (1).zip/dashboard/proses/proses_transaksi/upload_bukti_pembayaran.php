<?php

require '../koneksi.php';
require '../session.php';

$idTransaksi = $_POST['id_transaksi'];
$buktiBayarLama = $_POST['bukti_bayar_lama'];

// cek apakah user pilih gambar baru atau tidak
if ($_FILES["bukti_bayar"]["error"] == 4) {
    $buktiBayar = $buktiBayarLama;
} else {
    $buktiBayar = upload();
}

$input = mysqli_query($conn, "UPDATE tb_transaksi SET
                                        bukti = '$buktiBayar'
                                    WHERE id_transaksi = $idTransaksi
                            ");
if ($input) {
    echo "<script>
            alert('Bukti berhasil diupload');
            window.location.href = '../../transaksi';
        </script>";
} else {
    echo "<script>
            alert('Bukti gagal diupload');
            window.location = '../../transaksi';
        </script>";
}

function upload()
{
    $namaFile = $_FILES['bukti_bayar']['name'];
    $ukuranFile = $_FILES['bukti_bayar']['size'];
    $error = $_FILES['bukti_bayar']['error'];
    $tmpName = $_FILES['bukti_bayar']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        echo "
            <script>
                alert('Pilih gambar terlebih dahulu!');
                window.location = '../../transaksi';
            </script>";
    } else {
        // cek apakah yang diupload adalah gambar
        $validImageExt = ['jpg', 'jpeg', 'png'];
        $imageExt = explode('.', $namaFile);
        $imageExt = strtolower(end($imageExt));

        if (!in_array($imageExt, $validImageExt)) {
            echo "
            <script>
                alert('Yang anda upload bukan gambar!');
                window.location = '../../transaksi';
            </script>";
        }
        // cek jika ukurannya terlalu besar
        elseif ($ukuranFile > 2000000) {
            echo "
            <script>
                alert('Ukuran gambar terlalu besar!');
                window.location = '../../transaksi';
            </script>";
        } else {
            // lolos pengecekan, gambar siap diupload
            // generate nama gambar baru
            $namaFileBaru = uniqid();
            $namaFileBaru .= '.';
            $namaFileBaru .= $imageExt;

            move_uploaded_file($tmpName, '../../img/bukti_pembayaran/' . $namaFileBaru);

            return $namaFileBaru;
        }
    }
}
