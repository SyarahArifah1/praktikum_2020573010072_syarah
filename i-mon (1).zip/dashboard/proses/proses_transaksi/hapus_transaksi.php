<?php

require '../koneksi.php';

$idTransaksi = $_POST['id_transaksi'];

$query = mysqli_query($conn, "SELECT bukti FROM tb_transaksi WHERE id_transaksi = $idTransaksi");
$data = mysqli_fetch_assoc($query);
unlink("../../img/bukti_pembayaran/" . $data['bukti']);

$sql = mysqli_query($conn, "DELETE FROM tb_transaksi WHERE id_transaksi = $idTransaksi");


if ($sql) {
    echo "<script>
                alert('Data Transaksi berhasil dihapus');
                window.location = '../../transaksi';
              </script>";
} else {
    echo "<script>
                alert('Data Transaksi gagal dihapus');
                window.location = '../../transaksi';
              </script>";
}
