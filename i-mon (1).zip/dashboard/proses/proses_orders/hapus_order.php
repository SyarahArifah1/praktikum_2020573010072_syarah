<?php 
    require "../koneksi.php";

    $idOrder = $_POST['id_order'];

    $sql = mysqli_query($conn, "DELETE FROM tb_orders WHERE id_order = $idOrder");
    if ( $sql ) {
        echo "<script>
                alert('Orderan berhasil dihapus');
                window.location = '../../orders';
              </script>";
    }
    else {
        echo "<script>
                alert('Orderan gagal dihapus');
                window.location = '../../orders';
              </script>";
    }
