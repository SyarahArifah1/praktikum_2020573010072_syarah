<?php 
    require '../koneksi.php';
    require '../session.php';

    $idOrder = $_POST['id_order'];
    $customer = $_POST['customer'];
    $jumlah = $_POST['jumlah'];
    $metodeBayar = $_POST['metode_bayar'];

    if (empty($jumlah)) {
        echo "<script>
                alert('Jumlah pesanan harus diisi!');
                window.location = '../../orders';
            </script>";
    } else {
        $input = mysqli_query($conn, "UPDATE tb_orders SET
                                        user = $customer,
                                        qty = $jumlah,
                                        total_harga = $jumlah*12000,
                                        metode_pembayaran = $metodeBayar
                                    WHERE id_order = $idOrder
                            ");
        if ($input) {
            echo "<script>
                alert('Orderan berhasil diubah');
                window.location = '../../orders';
            </script>";
        } else {
            echo "<script>
                alert('Orderan gagal diubah');
                window.location = '../../orders';
            </script>";
        }
    }
