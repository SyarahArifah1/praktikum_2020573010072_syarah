<?php 
    require '../koneksi.php';
    require '../session.php';

    $customer = $_POST['customer'];
    $jumlah = $_POST['jumlah'];
    $metodeBayar = $_POST['metode_bayar'];

    if (empty($jumlah)) {
        echo "<script>
                alert('Jumlah pesanan harus diisi!');
                window.location = '../../orders';
            </script>";
    } else {
        $input = mysqli_query($conn, "INSERT INTO tb_orders (user, qty, total_harga, metode_pembayaran, status_order)
                                        VALUES ($customer, $jumlah, $jumlah*12000, $metodeBayar, 1)
                            
                            ");
        if ($input) {
            echo "<script>
                alert('Orderan berhasil dibuat');
                window.location = '../../orders';
            </script>";
        } else {
            echo "<script>
                alert('Orderan gagal dibuat');
                window.location = '../../orders';
            </script>";
        }
    }
