<?php
    require '../koneksi.php';
    require '../session.php';

    $query = mysqli_query($conn, "SELECT password FROM tb_users WHERE email = '$_SESSION[email]'");
    $data = mysqli_fetch_assoc($query);

    // ambil id dari halaman settings.php
    $id = $_POST["id"];

    $password = md5($_POST['password']);
    $NewPassword = $_POST['newpassword'];
    $NewPassword2 = $_POST['newpassword2'];

    // cek password lama benar atau salah
    if ( $password !== $data['password'] ) {
        echo "<script>
                alert('password anda yang sekarang salah!');
                window.location = '../../settings';
              </script>";
        return false;
    }
    
    // cek konfirmasi password
    if ( $NewPassword !== $NewPassword2 ) {
        echo "<script>
                alert('konfirmasi password tidak sesuai');
                window.location = '../../settings';
              </script>";
        return false;
    }

    // enkripsi passsword
    $NewPassword = md5($NewPassword);

    // update password pada database
    mysqli_query($conn, "UPDATE tb_users SET password = '$NewPassword' WHERE id = $id");

    // cek apakah password berhasil di update pada database
    $berhasil = mysqli_affected_rows($conn);
    if ( $berhasil > 0 ) {
        echo "<script>
                alert('Password berhasil diubah!');
                window.location = '../../settings';
              </script>";
    }
    else {
        echo "<script>
                alert('Password gagal diubah!');
                window.location = '../../settings';
              </script>";
    }
