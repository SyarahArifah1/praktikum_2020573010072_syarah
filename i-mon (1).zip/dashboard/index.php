<?php
    if ( !isset($_GET['x']) ) {
        echo "<script> window.location = 'home' </script>";
    }
    elseif ( $_GET['x'] == 'home' ) {
        require "home.php";
    }
    elseif ( $_GET['x'] == 'orders' ) {
        require "orders.php";
    }
    elseif ( $_GET['x'] == 'transaksi' ) {
        require "transaksi.php";
    }
    elseif ( $_GET['x'] == 'users' ) {
        require "users.php";
    }
    elseif ( $_GET['x'] == 'profile' ) {
        require "profile.php";
    }
    elseif ( $_GET['x'] == 'settings' ) {
        require "settings.php";
    }
    else {
        echo "<script> window.location = 'home' </script>";
    }
?>