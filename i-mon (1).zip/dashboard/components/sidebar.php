<?php
require 'proses/koneksi.php';

$hasil = mysqli_query($conn, "SELECT id, nama, foto, level FROM tb_users u
                                    LEFT JOIN tb_profiles p ON u.id = p.id_user
                                    WHERE email = '$_SESSION[email]'
                        ");
$row = mysqli_fetch_assoc($hasil);
?>

<nav class="p-3">
  <div class="brand text-center">
    <img class="py-3 py-md-4" src="img/i-mon.png" alt="I-MON">
  </div>
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <?php if ($row['level'] == 'admin') : ?>
        <li class="nav-item my-1">
          <a class="nav-link 
        <?php if ($_GET['x'] == "home") echo "active"; ?>" href="home">
            <!-- <i class="fa-regular fa-chart-pie-simple me-2"></i> -->
            <i class="fa-regular fa-gauge-simple-max me-2"></i>
            Dashboard
          </a>
        </li>
      <?php endif ?>

      <?php if ($row['level'] == 'admin' || $row['level'] == 'user') : ?>
      <li class="nav-item my-1">
        <a class="nav-link 
        <?php if ($_GET['x'] == "orders") echo "active"; ?>" href="orders">
          <i class="fa-regular fa-cart-shopping me-2"></i>
          Orderan
        </a>
      </li>
      <?php endif ?>

      <?php if ($row['level'] == 'admin' || $row['level'] == 'user') : ?>
      <li class="nav-item my-1">
        <a class="nav-link 
        <?php if ($_GET['x'] == "transaksi") echo "active"; ?>" href="transaksi">
          <i class="fa-regular fa-money-check me-2"></i>
          Transaksi
        </a>
      </li>
      <?php endif ?>

      <?php if ($row['level'] == 'admin') : ?>
      <li class="nav-item my-1">
        <a class="nav-link 
        <?php if ($_GET['x'] == "users") echo "active"; ?>" href="users">
          <i class="fa-regular fa-user-group me-2"></i>
          Users
        </a>
      </li>
      <?php endif ?>
    </ul>
  </div>
</nav>