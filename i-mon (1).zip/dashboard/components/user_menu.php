<div class="dropdown">
    <a class="link-dark text-decoration-none shadow" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
        <?php
        if (empty($row['foto'])) {
            $foto = 'avatar.png';
        } else {
            $foto = $row['foto'];
        }
        ?>
        <img class="rounded-3" src="img/<?= $foto ?>" alt="Rizky" width="36px" height="36px">
    </a>

    <ul class="dropdown-menu p-2 mt-3" aria-labelledby="dropdownMenuLink">
        <li>
            <button class="dropdown-item text-dark" disabled>
                <strong>
                    <?php
                    $nama = $row['nama'];
                    $nama = explode(' ', $nama);
                    echo $nama[0];
                    ?>
                </strong>
            </button>
        </li>
        <li>
            <a class="dropdown-item" href="profile">
                <i class="fa-regular fa-user me-1"></i>
                Profile
            </a>
        </li>
        <li>
            <a class="dropdown-item" href="settings">
                <i class="fa-regular fa-gear me-1"></i>
                Settings
            </a>
        </li>
        <li>
            <hr class="dropdown-divider" />
        </li>
        <li>
            <a class="dropdown-item" href="proses/proses_auth/logout.php">
                <i class="fa-regular fa-arrow-right-from-bracket me-2"></i>
                Logout
            </a>
        </li>
    </ul>
</div>