<?php

require 'proses/koneksi.php';
require "proses/session.php";

$sql = mysqli_query($conn, "SELECT * FROM tb_orders o
                                LEFT JOIN tb_users u ON o.user = u.id
                                LEFT JOIN tb_profiles p ON o.user = p.id_user
                                ORDER BY tgl_order DESC
                        ");

$sql1 = mysqli_query($conn, "SELECT * FROM tb_orders o
                                LEFT JOIN tb_users u ON o.user = u.id
                                LEFT JOIN tb_profiles p ON o.user = p.id_user
                                WHERE email = '$_SESSION[email]'
                                ORDER BY tgl_order DESC
                        ");

$aktif = mysqli_query($conn, "SELECT * FROM tb_orders WHERE status_order = 1");
$proses = mysqli_query($conn, "SELECT * FROM tb_orders WHERE status_order = 4");
$selesai = mysqli_query($conn, "SELECT * FROM tb_orders WHERE status_order = 2");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" /> -->
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Rubik Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Datatables Style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">

    <!-- Dashboard Style -->
    <link rel="stylesheet" href="css/dashboard.css">

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v6.0.0-beta3/css/all.css">

    <title>Dashboard - I-MON</title>
</head>

<body>
    <div class="navbar navbar-light sticky-top bg-light d-md-none flex-md-nowrap pb-5 shadow">
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fa-solid fa-bars display-6"></span>
        </button>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <!-- Sidebar -->
                <?php require 'components/sidebar.php' ?>
                <!-- End Sidebar -->
            </div>

            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <header>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 my-3">
                        <h1 class="h2">Orders</h1>
                        <!-- User Menu -->
                        <?php require 'components/user_menu.php' ?>
                        <!-- End User Menu -->
                    </div>
                </header>

                <main>
                    <?php if ($row['level'] == 'admin') : ?>
                        <div class="row">
                            <div class="col-sm-6 col-lg-3 mt-3">
                                <div class="card revenue-info p-1 shadow-sm border-0">
                                    <div class="card-body">
                                        <i class="fa-duotone fa-cart-shopping fa-2x p-2 rounded-3 bg-white"></i>
                                        <h4 class="card-title mt-3"><?= mysqli_num_rows($aktif) ?></h4>
                                        <p class="card-text lh-1">Orderan Aktif</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3 mt-3">
                                <div class="card bg-info p-1 shadow-sm border-0">
                                    <div class="card-body">
                                        <i class="fa-duotone fa-loader fa-2x p-2 rounded-3 bg-white text-info"></i>
                                        <h4 class="card-title mt-3"><?= mysqli_num_rows($proses) ?></h4>
                                        <p class="card-text lh-1">Orderan Diproses</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3 mt-3">
                                <div class="card earnings-info p-1 shadow-sm border-0">
                                    <div class="card-body">
                                        <i class="fa-duotone fa-cart-circle-check fa-2x p-2 rounded-3 bg-white"></i>
                                        <h4 class="card-title mt-3"><?= mysqli_num_rows($selesai) ?></h4>
                                        <p class="card-text lh-1">Orderan Selesai</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif ?>

                    <div class="card mt-5 mb-4 shadow">
                        <div class="card-body">
                            <div class="p-2">
                                <h3 class="card-title">Recent Orders</h3>
                                <button type="button" class="btn btn-primary rounded-3 my-3" data-bs-toggle="modal" data-bs-target="#addModal">
                                    <i class="fa-regular fa-plus me-1"></i>
                                    Buat Orderan
                                </button>

                                <?php if ($row['level'] == 'admin') : ?>
                                    <!-- Tabel orders untuk admin -->
                                    <table id="example" class="table responsive nowrap table-bordered table-striped align-middle" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>ID Order</th>
                                                <th>Tanggal Order</th>
                                                <th>Customer</th>
                                                <th>Telepon</th>
                                                <th>Jumlah</th>
                                                <th>Total</th>
                                                <th>Metode Pembayaran</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $num = 1;
                                            while ($data = mysqli_fetch_assoc($sql)) :
                                            ?>
                                                <tr>
                                                    <td><?= $num ?></td>
                                                    <td><?= '#' . $data['id_order'] ?></td>
                                                    <td>
                                                        <?php
                                                        $tglOrder = $data['tgl_order'];
                                                        $tglOrder = explode(' ', $tglOrder);
                                                        echo $tglOrder[0];
                                                        ?>
                                                    </td>
                                                    <td><?= $data['nama'] ?></td>
                                                    <td>
                                                        <?php
                                                        $telepon = $data['telepon'];
                                                        $telepon = str_split($telepon, 4);
                                                        $telepon = implode('-', $telepon);
                                                        echo $telepon;
                                                        ?>
                                                    </td>
                                                    <td><?= $data['qty'] ?></td>
                                                    <td>
                                                        <?php
                                                        $totalHarga = $data['total_harga'];
                                                        $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                        echo $totalHarga;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($data['metode_pembayaran'] == 1) {
                                                            echo 'Cash On Delivery (COD)';
                                                        } elseif ($data['metode_pembayaran'] == 2) {
                                                            echo 'OVO';
                                                        } elseif ($data['metode_pembayaran'] == 3) {
                                                            echo 'DANA';
                                                        } elseif ($data['metode_pembayaran'] == 4) {
                                                            echo 'Transfer via Bank BSI';
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <?php
                                                        if ($data['status_order'] == 1) {
                                                            $bg = "warning text-dark";
                                                            $status = "Pending";
                                                        } elseif ($data['status_order'] == 2) {
                                                            $bg = "success";
                                                            $status = "Berhasil";
                                                        } elseif ($data['status_order'] == 3) {
                                                            $bg = "danger";
                                                            $status = "Gagal";
                                                        } elseif ($data['status_order'] == 4) {
                                                            $bg = "info text-dark";
                                                            $status = "Proses";
                                                        }
                                                        ?>
                                                        <span class="badge bg-<?= $bg ?>"><?= $status ?></span>
                                                    </td>
                                                    <td>
                                                        <?php if ($data['status_order'] == 1 || $data['status_order'] == 3) : ?>
                                                            <button type="button" class="btn btn-primary rounded-3" data-bs-toggle="modal" data-bs-target="#modalBayar<?= $num ?>">
                                                                <i class="fa-regular fa-money-bill-wave me-1"></i>
                                                                Bayar
                                                            </button>
                                                            <button type="button" class="btn btn-warning rounded-3" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $num ?>">
                                                                <i class="fa-regular fa-pen-to-square"></i>
                                                            </button>
                                                        <?php endif ?>
                                                        <button type="button" class="btn btn-danger rounded-3" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $num ?>">
                                                            <i class="fa-regular fa-trash-can"></i>
                                                        </button>
                                                    </td>
                                                </tr>

                                                <!-- modal bayar order -->
                                                <div class="modal fade" id="modalBayar<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Bayar Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_transaksi/tambah_transaksi.php" method="post">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="id_order" value="<?= $data['id_order'] ?>">
                                                                    <input type="hidden" name="user" value="<?= $data['user'] ?>">
                                                                    <input type="hidden" name="total_bayar" value="<?= $data['total_harga'] ?>">
                                                                    <div class="details">
                                                                        <h6 class="fw-bold">Rincian Pembayaran</h6>
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <p>Air Minum Galon x <?= $data['qty'] ?></p>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $totalHarga = $data['total_harga'] - $data['qty'] * 2000;
                                                                                $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                                                echo $totalHarga;
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <p>Biaya Antar</p>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $biayaAntar = $data['qty'] * 2000;
                                                                                $biayaAntar = "Rp " . number_format($biayaAntar, 0, ',', '.');
                                                                                echo $biayaAntar;
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <p class="fw-bold">Total Bayar</pc>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $totalHarga = $data['total_harga'];
                                                                                $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                                                echo "<b>$totalHarga</b>";
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-3">
                                                                            <?php
                                                                            if ($data['metode_pembayaran'] == 1) {
                                                                                $metode = 'Cash On Delivery (COD)';
                                                                            } elseif ($data['metode_pembayaran'] == 2) {
                                                                                $metode = 'OVO';
                                                                                $rek = '082361002021';
                                                                            } elseif ($data['metode_pembayaran'] == 3) {
                                                                                $metode = 'DANA';
                                                                                $rek = '082361002021';
                                                                            } elseif ($data['metode_pembayaran'] == 4) {
                                                                                $metode = 'Transfer via Bank BSI';
                                                                                $rek = '1169961919';
                                                                            }
                                                                            ?>
                                                                            <h6 class="fw-bold"><?= $metode ?></h6>
                                                                            <p class="lh-base">
                                                                                a.n UD. I-MON Masak <br>
                                                                                <?= "No. Rekening : <b>$rek</b>" ?>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary">Bayar</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal bayar order -->

                                                <!-- modal edit order -->
                                                <div class="modal fade" id="modalEdit<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Edit Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_orders/edit_order.php" method="post">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="id_order" value="<?= $data['id_order'] ?>">
                                                                    <div class="mb-3">
                                                                        <?php if ($row['level'] == 'admin') : ?>
                                                                            <label for="customer" class="form-label">Nama Customer</label>
                                                                            <select class="form-select" id="customer" name="customer">
                                                                                <?php
                                                                                $result = mysqli_query($conn, "SELECT id, nama FROM tb_users u LEFT JOIN tb_profiles p ON u.id = p.id_user");
                                                                                while ($record = mysqli_fetch_assoc($result)) :
                                                                                    if ($record['id'] == $data['id']) :
                                                                                ?>
                                                                                        <option value="<?= $record['id'] ?>" selected>
                                                                                            <?= $record['id'] . ' - ' . $record['nama'] ?>
                                                                                        </option>
                                                                                    <?php else : ?>
                                                                                        <option value="<?= $record['id'] ?>">
                                                                                            <?= $record['id'] . ' - ' . $record['nama'] ?>
                                                                                        </option>
                                                                                <?php
                                                                                    endif;
                                                                                endwhile;
                                                                                ?>
                                                                            </select>
                                                                        <?php elseif ($row['level'] == 'user') : ?>
                                                                            <input type="hidden" name="customer" value="<?= $row['id'] ?>">
                                                                        <?php endif ?>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="jumlah" class="form-label">Jumlah</label>
                                                                        <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $data['qty'] ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="metode_bayar" class="form-label">Metode Pembayaran</label>
                                                                        <select class="form-select" id="metode_bayar" name="metode_bayar">
                                                                            <option value="1">Cash On Delivery (COD)</option>
                                                                            <option value="2">OVO</option>
                                                                            <option value="3">DANA</option>
                                                                            <option value="4">Transfer via Bank BSI</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal edit order -->

                                                <!-- modal hapus order -->
                                                <div class="modal fade" id="modalHapus<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Hapus Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_orders/hapus_order.php" method="post">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="id_order" value="<?= $data['id_order'] ?>">
                                                                    <p>Apakah anda yakin ingin menghapus orderan ini?</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal hapus order -->

                                            <?php
                                                $num++;
                                            endwhile
                                            ?>
                                        </tbody>
                                    </table>

                                <?php elseif ($row['level'] == 'user') : ?>
                                    <!-- Tabel orders untuk user -->
                                    <table id="example" class="table responsive nowrap table-bordered table-striped align-middle" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>ID Order</th>
                                                <th>Tanggal Order</th>
                                                <th>Customer</th>
                                                <th>Telepon</th>
                                                <th>Jumlah</th>
                                                <th>Total</th>
                                                <th>Metode Pembayaran</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $num = 1;
                                            while ($data1 = mysqli_fetch_assoc($sql1)) :
                                            ?>
                                                <tr>
                                                    <td><?= $num ?></td>
                                                    <td><?= '#' . $data1['id_order'] ?></td>
                                                    <td>
                                                        <?php
                                                        $tglOrder = $data1['tgl_order'];
                                                        $tglOrder = explode(' ', $tglOrder);
                                                        echo $tglOrder[0];
                                                        ?>
                                                    </td>
                                                    <td><?= $data1['nama'] ?></td>
                                                    <td>
                                                        <?php
                                                        $telepon = $data1['telepon'];
                                                        $telepon = str_split($telepon, 4);
                                                        $telepon = implode('-', $telepon);
                                                        echo $telepon;
                                                        ?>
                                                    </td>
                                                    <td><?= $data1['qty'] ?></td>
                                                    <td>
                                                        <?php
                                                        $totalHarga = $data1['total_harga'];
                                                        $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                        echo $totalHarga;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($data1['metode_pembayaran'] == 1) {
                                                            echo 'Cash On Delivery (COD)';
                                                        } elseif ($data1['metode_pembayaran'] == 2) {
                                                            echo 'OVO';
                                                        } elseif ($data1['metode_pembayaran'] == 3) {
                                                            echo 'DANA';
                                                        } elseif ($data1['metode_pembayaran'] == 4) {
                                                            echo 'Transfer via Bank BSI';
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <?php
                                                        if ($data1['status_order'] == 1) {
                                                            $bg = "warning text-dark";
                                                            $status = "Pending";
                                                        } elseif ($data1['status_order'] == 2) {
                                                            $bg = "success";
                                                            $status = "Berhasil";
                                                        } elseif ($data1['status_order'] == 3) {
                                                            $bg = "danger";
                                                            $status = "Gagal";
                                                        } elseif ($data1['status_order'] == 4) {
                                                            $bg = "info text-dark";
                                                            $status = "Proses";
                                                        }
                                                        ?>
                                                        <span class="badge bg-<?= $bg ?>"><?= $status ?></span>
                                                    </td>
                                                    <td>
                                                        <?php if ($data1['status_order'] == 1 || $data1['status_order'] == 3) : ?>
                                                            <button type="button" class="btn btn-primary rounded-3" data-bs-toggle="modal" data-bs-target="#modalBayar<?= $num ?>">
                                                                <i class="fa-regular fa-money-bill-wave me-1"></i>
                                                                Bayar
                                                            </button>
                                                            <button type="button" class="btn btn-warning rounded-3" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $num ?>">
                                                                <i class="fa-regular fa-pen-to-square"></i>
                                                            </button>
                                                        <?php endif ?>

                                                        <?php if ($data1['status_order'] != 2) : ?>
                                                            <button type="button" class="btn btn-danger rounded-3" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $num ?>">
                                                                <i class="fa-regular fa-trash-can"></i>
                                                            </button>
                                                        <?php endif ?>
                                                    </td>
                                                </tr>

                                                <!-- modal bayar order -->
                                                <div class="modal fade" id="modalBayar<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Bayar Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_transaksi/tambah_transaksi.php" method="post">
                                                                <div class="modal-body">
                                                                    <?= $data1['id_order'] . ' - ' . $data1['user'] ?>
                                                                    <input type="hidden" name="id_order" value="<?= $data1['id_order'] ?>">
                                                                    <input type="hidden" name="user" value="<?= $data1['user'] ?>">
                                                                    <input type="hidden" name="total_bayar" value="<?= $data1['total_harga'] ?>">
                                                                    <div class="details">
                                                                        <h6 class="fw-bold">Rincian Pembayaran</h6>
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <p>Air Minum Galon x <?= $data1['qty'] ?></p>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $totalHarga = $data1['total_harga'] - $data1['qty'] * 2000;
                                                                                $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                                                echo $totalHarga;
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <p>Biaya Antar</p>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $biayaAntar = $data1['qty'] * 2000;
                                                                                $biayaAntar = "Rp " . number_format($biayaAntar, 0, ',', '.');
                                                                                echo $biayaAntar;
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <p class="fw-bold">Total Bayar</pc>
                                                                            </div>
                                                                            <div class="col-md-4 ms-auto text-end">
                                                                                <?php
                                                                                $totalHarga = $data1['total_harga'];
                                                                                $totalHarga = "Rp " . number_format($totalHarga, 0, ',', '.');
                                                                                echo "<b>$totalHarga</b>";
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mt-3">
                                                                            <?php
                                                                            if ($data1['metode_pembayaran'] == 1) {
                                                                                $metode = 'Cash On Delivery (COD)';
                                                                            } elseif ($data1['metode_pembayaran'] == 2) {
                                                                                $metode = 'OVO';
                                                                                $rek = '082361002021';
                                                                            } elseif ($data1['metode_pembayaran'] == 3) {
                                                                                $metode = 'DANA';
                                                                                $rek = '082361002021';
                                                                            } elseif ($data1['metode_pembayaran'] == 4) {
                                                                                $metode = 'Transfer via Bank BSI';
                                                                                $rek = '1169961919';
                                                                            }
                                                                            ?>
                                                                            <h6 class="fw-bold"><?= $metode ?></h6>
                                                                            <p class="lh-base">
                                                                                a.n UD. I-MON Masak <br>
                                                                                <?= "No. Rekening : <b>$rek</b>" ?>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary">Bayar</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal bayar order -->

                                                <!-- modal edit order -->
                                                <div class="modal fade" id="modalEdit<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Edit Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_orders/edit_order.php" method="post">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="id_order" value="<?= $data1['id_order'] ?>">
                                                                    <div class="mb-3">
                                                                        <?php if ($row['level'] == 'admin') : ?>
                                                                            <label for="customer" class="form-label">Nama Customer</label>
                                                                            <select class="form-select" id="customer" name="customer">
                                                                                <?php
                                                                                $result = mysqli_query($conn, "SELECT id, nama FROM tb_users u LEFT JOIN tb_profiles p ON u.id = p.id_user");
                                                                                while ($record = mysqli_fetch_assoc($result)) :
                                                                                    if ($record['id'] == $data1['id']) :
                                                                                ?>
                                                                                        <option value="<?= $record['id'] ?>" selected>
                                                                                            <?= $record['id'] . ' - ' . $record['nama'] ?>
                                                                                        </option>
                                                                                    <?php else : ?>
                                                                                        <option value="<?= $record['id'] ?>">
                                                                                            <?= $record['id'] . ' - ' . $record['nama'] ?>
                                                                                        </option>
                                                                                <?php
                                                                                    endif;
                                                                                endwhile;
                                                                                ?>
                                                                            </select>
                                                                        <?php elseif ($row['level'] == 'user') : ?>
                                                                            <input type="hidden" name="customer" value="<?= $row['id'] ?>">
                                                                        <?php endif ?>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="jumlah" class="form-label">Jumlah</label>
                                                                        <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $data1['qty'] ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="metode_bayar" class="form-label">Metode Pembayaran</label>
                                                                        <select class="form-select" id="metode_bayar" name="metode_bayar">
                                                                            <option value="1">Cash On Delivery (COD)</option>
                                                                            <option value="2">OVO</option>
                                                                            <option value="3">DANA</option>
                                                                            <option value="4">Transfer via Bank BSI</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal edit order -->

                                                <!-- modal hapus order -->
                                                <div class="modal fade" id="modalHapus<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-md">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Hapus Pesanan</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="proses/proses_orders/hapus_order.php" method="post">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="id_order" value="<?= $data1['id_order'] ?>">
                                                                    <p>Apakah anda yakin ingin menghapus orderan ini?</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end modal hapus order -->

                                            <?php
                                                $num++;
                                            endwhile
                                            ?>
                                        </tbody>
                                    </table>

                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- new order modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Buat Orderan Langsung</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="proses/proses_orders/tambah_order.php" method="post">
                    <div class="modal-body">
                        <?php if ($row['level'] == 'admin') : ?>
                            <div class="mb-3">
                                <label for="customer" class="form-label">Nama Customer</label>
                                <select class="form-select" id="customer" name="customer">
                                    <?php
                                    $result = mysqli_query($conn, "SELECT id, nama FROM tb_users u LEFT JOIN tb_profiles p ON u.id = p.id_user");
                                    while ($record = mysqli_fetch_assoc($result)) :
                                    ?>
                                        <option value="<?= $record['id'] ?>">
                                            <?= $record['id'] . ' - ' . $record['nama'] ?>
                                        </option>
                                    <?php endwhile ?>
                                </select>
                            </div>
                        <?php elseif ($row['level'] == 'user') : ?>
                            <input type="hidden" name="customer" value="<?= $row['id'] ?>">
                        <?php endif ?>

                        <div class="mb-3">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah">
                        </div>
                        <div class="mb-3">
                            <label for="metode_bayar" class="form-label">Metode Pembayaran</label>
                            <select class="form-select" id="metode_bayar" name="metode_bayar">
                                <option value="1">Cash On Delivery (COD)</option>
                                <option value="2">OVO</option>
                                <option value="3">DANA</option>
                                <option value="4">Transfer via Bank BSI</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Buat</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end new order modal -->




    <!-- Datatables Js -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>

    <script src="js/datatables.js"></script>

    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>