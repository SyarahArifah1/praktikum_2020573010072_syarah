<?php
require 'proses/koneksi.php';
require "proses/session.php";

$sql = mysqli_query($conn, "SELECT * FROM tb_transaksi tr
                            LEFT JOIN tb_orders o ON tr.id_order = o.id_order
                            LEFT JOIN tb_users u ON o.user = u.id
                            LEFT JOIN tb_profiles p ON o.user = p.id_user
                            ORDER BY tgl_transaksi DESC
                        ");

$sql1 = mysqli_query($conn, "SELECT * FROM tb_transaksi tr
                            LEFT JOIN tb_orders o ON tr.id_order = o.id_order
                            LEFT JOIN tb_users u ON o.user = u.id
                            LEFT JOIN tb_profiles p ON o.user = p.id_user
                            WHERE email = '$_SESSION[email]'
                            ORDER BY tgl_transaksi DESC
                        ");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" /> -->
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Rubik Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Datatables Style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">

    <!-- Dashboard Style -->
    <link rel="stylesheet" href="css/dashboard.css">

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v6.0.0-beta3/css/all.css">

    <title>Dashboard - I-MON</title>
</head>

<body>
    <div class="navbar navbar-light sticky-top bg-light d-md-none flex-md-nowrap pb-5 shadow">
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fa-solid fa-bars display-6"></span>
        </button>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <!-- Sidebar -->
                <?php require 'components/sidebar.php' ?>
                <!-- End Sidebar -->
            </div>

            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <header>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 my-3">
                        <h1 class="h2">Daftar Transaksi</h1>
                        <!-- User Menu -->
                        <?php require 'components/user_menu.php' ?>
                        <!-- End User Menu -->
                    </div>
                </header>

                <main>
                    <div class="card mb-4 shadow">
                        <div class="card-body">

                            <?php if ($row['level'] == 'admin') : ?>
                                <!-- Tabel orders untuk admin -->
                                <table id="example" class="table responsive nowrap table-bordered table-striped align-middle" style="width:100%">
                                    <thead>
                                        <tr class="bg-white">
                                            <th scope="col">No</th>
                                            <th scope="col">ID Transaksi</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">ID Order</th>
                                            <th scope="col">Customer</th>
                                            <th scope="col">Total Bayar</th>
                                            <th scope="col">Metode Pembayaran</th>
                                            <th scope="col">Bukti Pembayaran</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $num = 1;
                                        while ($data = mysqli_fetch_assoc($sql)) :
                                        ?>
                                            <tr>
                                                <td><?= $num ?></td>
                                                <td><?= $data['id_transaksi'] ?></td>
                                                <td>
                                                    <?php
                                                    $tglTransaksi = $data['tgl_transaksi'];
                                                    $tglTransaksi = explode(' ', $tglTransaksi);
                                                    echo $tglTransaksi[0];
                                                    ?>
                                                </td>
                                                <td><?= '#' . $data['id_order'] ?></td>
                                                <td><?= $data['nama'] ?></td>
                                                <td>
                                                    <?php
                                                    $totalBayar = $data['total_bayar'];
                                                    $totalBayar = "Rp " . number_format($totalBayar, 0, ',', '.');
                                                    echo $totalBayar;
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if ($data['metode_pembayaran'] == 1) {
                                                        echo 'Cash On Delivery (COD)';
                                                    } elseif ($data['metode_pembayaran'] == 2) {
                                                        echo 'OVO';
                                                    } elseif ($data['metode_pembayaran'] == 3) {
                                                        echo 'DANA';
                                                    } elseif ($data['metode_pembayaran'] == 4) {
                                                        echo 'Transfer via Bank BSI';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php if (!empty($data['bukti'])) : ?>
                                                        <button type="button" class="btn btn-info rounded-3" data-bs-toggle="modal" data-bs-target="#buktiBayar<?= $num ?>">
                                                            <i class="fa-regular fa-circle-info me-2"></i>
                                                            Lihat
                                                        </button>

                                                    <?php else : ?>
                                                        <button type="button" class="btn btn-secondary rounded-3" data-bs-toggle="modal" data-bs-target="#buktiBayar<?= $num ?>">
                                                            <i class="fa-regular fa-arrow-up-from-bracket me-2"></i>
                                                            Upload
                                                        </button>
                                                    <?php endif ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php
                                                    if ($data['status_transaksi'] == 1) {
                                                        $bg = "warning text-dark";
                                                        $status = "Pending";
                                                    } elseif ($data['status_transaksi'] == 2) {
                                                        $bg = "success";
                                                        $status = "Berhasil";
                                                    } elseif ($data['status_transaksi'] == 3) {
                                                        $bg = "danger";
                                                        $status = "Gagal";
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?= $bg ?>"><?= $status ?></span>
                                                </td>
                                                <td>
                                                    <?php if ($data['status_transaksi'] != 2) : ?>
                                                        <button type="button" class="btn btn-success rounded-3" data-bs-toggle="modal" data-bs-target="#konfirmasiBayar<?= $num ?>">
                                                            <i class="fa-regular fa-check"></i>
                                                        </button>
                                                    <?php endif ?>
                                                    <button type="button" class="btn btn-danger rounded-3" data-bs-toggle="modal" data-bs-target="#hapusTransaksi<?= $num ?>">
                                                        <i class="fa-regular fa-trash-can"></i>
                                                    </button>
                                                </td>
                                            </tr>

                                            <!-- modal bukti bayar -->
                                            <div class="modal fade" id="buktiBayar<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Bukti Pembayaran</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="proses/proses_transaksi/upload_bukti_pembayaran.php" method="post" enctype="multipart/form-data">
                                                            <input type="hidden" name="id_transaksi" value="<?= $data['id_transaksi'] ?>">
                                                            <input type="hidden" name="bukti_bayar_lama" value="<?= $data['bukti'] ?>">
                                                            <div class="modal-body">
                                                                <?php if (!empty($data['bukti'])) : ?>
                                                                    <img src="img/bukti_pembayaran/<?= $data['bukti'] ?>" alt="<?= 'Bukti - ' . $data['nama'] ?>" width="100%">
                                                                <?php endif ?>
                                                                <input class="mt-3 form-control form-control-sm" type="file" name="bukti_bayar" id="bukti_bayar">
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-primary">Upload</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end modal bukti bayar -->

                                            <!-- modal konfirmasi pembayaran -->
                                            <div class="modal fade" id="konfirmasiBayar<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Pembayaran</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="proses/proses_transaksi/konfirmasi_pembayaran.php" method="post">
                                                            <input type="hidden" name="id_order" value="<?= $data['id_order'] ?>">
                                                            <input type="hidden" name="id_transaksi" value="<?= $data['id_transaksi'] ?>">
                                                            <div class="modal-body">
                                                                <p>Konfirmasi Pembayaran <b><?= '#' . $data['id_transaksi'] . ' - ' . $data['nama'] ?></b>?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-outline-success">Konfirmasi</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end modal konfirmasi pembayaran -->

                                            <!-- modal hapus data transaksi -->
                                            <div class="modal fade" id="hapusTransaksi<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Hapus Data Transaksi</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="proses/proses_transaksi/hapus_transaksi.php" method="post">
                                                            <input type="hidden" name="id_transaksi" value="<?= $data['id_transaksi'] ?>">
                                                            <div class="modal-body">
                                                                <p>Hapus Transaksi <b><?= '#' . $data['id_transaksi'] . ' - ' . $data['nama'] ?></b>?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-outline-danger">Hapus</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end modal hapus data transaksi -->

                                        <?php
                                            $num++;
                                        endwhile;
                                        ?>
                                    </tbody>
                                </table>

                            <?php elseif ($row['level'] == 'user') : ?>
                                <!-- Tabel orders untuk user -->
                                <table id="example" class="table responsive nowrap table-bordered table-striped align-middle" style="width:100%">
                                    <thead>
                                        <tr class="bg-white">
                                            <th scope="col">No</th>
                                            <th scope="col">ID Transaksi</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">ID Order</th>
                                            <th scope="col">Customer</th>
                                            <th scope="col">Total Bayar</th>
                                            <th scope="col">Metode Pembayaran</th>
                                            <th scope="col">Bukti Pembayaran</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $num = 1;
                                        while ($data1 = mysqli_fetch_assoc($sql1)) :
                                        ?>
                                            <tr>
                                                <td><?= $num ?></td>
                                                <td><?= $data1['id_transaksi'] ?></td>
                                                <td>
                                                    <?php
                                                    $tglTransaksi = $data1['tgl_transaksi'];
                                                    $tglTransaksi = explode(' ', $tglTransaksi);
                                                    echo $tglTransaksi[0];
                                                    ?>
                                                </td>
                                                <td><?= '#' . $data1['id_order'] ?></td>
                                                <td><?= $data1['nama'] ?></td>
                                                <td>
                                                    <?php
                                                    $totalBayar = $data1['total_bayar'];
                                                    $totalBayar = "Rp " . number_format($totalBayar, 0, ',', '.');
                                                    echo $totalBayar;
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if ($data1['metode_pembayaran'] == 1) {
                                                        echo 'Cash On Delivery (COD)';
                                                    } elseif ($data1['metode_pembayaran'] == 2) {
                                                        echo 'OVO';
                                                    } elseif ($data1['metode_pembayaran'] == 3) {
                                                        echo 'DANA';
                                                    } elseif ($data1['metode_pembayaran'] == 4) {
                                                        echo 'Transfer via Bank BSI';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php if (!empty($data1['bukti'])) : ?>
                                                        <button type="button" class="btn btn-info rounded-3" data-bs-toggle="modal" data-bs-target="#buktiBayar<?= $num ?>">
                                                            <i class="fa-regular fa-circle-info me-2"></i>
                                                            Lihat
                                                        </button>

                                                    <?php else : ?>
                                                        <button type="button" class="btn btn-secondary rounded-3" data-bs-toggle="modal" data-bs-target="#buktiBayar<?= $num ?>">
                                                            <i class="fa-regular fa-arrow-up-from-bracket me-2"></i>
                                                            Upload
                                                        </button>
                                                    <?php endif ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php
                                                    if ($data1['status_transaksi'] == 1) {
                                                        $bg = "warning text-dark";
                                                        $status = "Pending";
                                                    } elseif ($data1['status_transaksi'] == 2) {
                                                        $bg = "success";
                                                        $status = "Berhasil";
                                                    } elseif ($data1['status_transaksi'] == 3) {
                                                        $bg = "danger";
                                                        $status = "Gagal";
                                                    }
                                                    ?>
                                                    <span class="badge bg-<?= $bg ?>"><?= $status ?></span>
                                                </td>
                                            </tr>

                                            <!-- modal bukti bayar -->
                                            <div class="modal fade" id="buktiBayar<?= $num ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Bukti Pembayaran</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="proses/proses_transaksi/upload_bukti_pembayaran.php" method="post" enctype="multipart/form-data">
                                                            <input type="hidden" name="id_transaksi" value="<?= $data1['id_transaksi'] ?>">
                                                            <input type="hidden" name="bukti_bayar_lama" value="<?= $data1['bukti'] ?>">
                                                            <div class="modal-body">
                                                                <?php if (!empty($data1['bukti'])) : ?>
                                                                    <img src="img/bukti_pembayaran/<?= $data1['bukti'] ?>" alt="<?= 'Bukti - ' . $data1['nama'] ?>" width="100%">
                                                                <?php endif ?>
                                                                <input class="mt-3 form-control form-control-sm" type="file" name="bukti_bayar" id="bukti_bayar">
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-primary">Upload</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end modal bukti bayar -->

                                        <?php
                                            $num++;
                                        endwhile;
                                        ?>
                                    </tbody>
                                </table>

                            <?php endif ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>




    <!-- Datatables Js -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>

    <script src="js/datatables.js"></script>

    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>